# F0 — Matrice delle differenze di runtime — revisione r3

Generato: 2026-08-22T17:09:59+00:00 — git HEAD `04c0c470da81`.

## Config confrontate (SHA-256)

| config | path | sha256 |
|---|---|---|
| JUN23_imit | Trajectory Generator/runs/training/MLP_imitation_training_06-23-2026_grfsoft_knee1_ankle2_100iter/training_cfg.resolved.yaml | fbe1fd3f03bdd118 |
| JUL_warmup_H0 | validation/critic_warmup/2026-07-13_markov35_phase_aligned_sigma0005_iter1_retry/training_cfg.resolved.yaml | 6904f7a9000b63b5 |
| JUL_pilot50 | Trajectory Generator/runs/training/validation/warm_start_h1_runs/2026-07-15_h0_exact_interleaved_lr5e-7_iter2-51_pilot50/training_cfg.resolved.yaml | f89d6b5ee9337c61 |
| V26_imit_june_equiv | Trajectory Generator/runs/training/MLP_imitation_native_v26_08-20-2026_june_equiv_100iter/training_cfg.resolved.yaml | aaf84cfd5be75672 |
| B0820_warmup | validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/training_cfg.resolved.yaml | 9882b33d385ada05 |
| B0820_v2_from_zero | Trajectory Generator/runs/training/MLP_ExNovo_B0820_from_zero_50iter/training_cfg.resolved.yaml | 0a19375462ff296f |
| B0820_v3_fixedcorridor | Trajectory Generator/runs/training/MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter/training_cfg.resolved.yaml | a870cc38a77d853b |
| chain_snapshot_B0820 | Trajectory Generator/baseline_MLP/experimental_configs/exnovo_v26_B0820_chain.yaml | b3e951ab43c9dec5 |
| canonical_editable_now | Trajectory Generator/baseline_MLP/training_exnovo_cfg.yaml | 092363e6bf5a411f |

## Profili referenziati (SHA-256)

| profilo | sha256 |
|---|---|
| grf_profile_tangent_v2 | 09e04ab94954703d74acc3a80b24ecefcc07d3fc918c03b9e9df8116a6c1a2b0 |
| grf_profile_grf_correct_magnitude | 09e04ab94954703d74acc3a80b24ecefcc07d3fc918c03b9e9df8116a6c1a2b0 |
| grf_detector_profile_HS-TO | 61ea948a3c0613e5c0e684a3197de118c7116e36188fca6993da79ce713fd99e |
| binary_phase_detector_v25_selected_candidate | db704e502b99e49bea6d89493812bafdac748f8ce8d3ce28214ff624078539a2 |
| morphology_event_warped | 33b1dd7cb0db40110a4f9c1b8c0dd49a498662211e6e132f0f3cefe8edc02a55 |
| morphology_legacy_mean_std | 6307119c2bb233831eac7070726fc6e2e0175c8f715a9fbbb787c0763b46fab7 |

Profilo GRF applicato: `tangent_v2` (B0820/giugno) e `grf_correct_magnitude` (luglio) hanno SHA-256 **identico** -> stessa fisica di contatto, solo nome diverso (rename).

## Voci dichiarate dal piano (valori per config)

| voce | chiave | JUN23_imit | JUL_warmup_H0 | JUL_pilot50 | V26_imit_june_equiv | B0820_warmup | B0820_v2_from_zero | B0820_v3_fixedcorridor | chain_snapshot_B0820 | canonical_editable_now |
|---|---|---|---|---|---|---|---|---|---|---|
| Profilo GRF applicato | grf.online_grf_profile | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_correct_magnitude.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_correct_magnitude.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json |
| Profilo detector GRF legacy HS/TO | grf.online_grf_detector_profile | <absent> | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json |
| Blocco binary_phase: modalita FSM | grf.binary_phase_fsm_mode | <absent> | <absent> | <absent> | binary_active | binary_active | binary_active | binary_active | binary_active | binary_active |
| Blocco binary_phase: profilo detector V25 | grf.binary_phase_detector_profile | <absent> | <absent> | <absent> | validation/binary_phase_detector_v25_geometry_runs/2026-08-04_local_reach_sweep_dev02_04_08/selected_candidate_profile.json | validation/binary_phase_detector_v25_geometry_runs/2026-08-04_local_reach_sweep_dev02_04_08/selected_candidate_profile.json | validation/binary_phase_detector_v25_geometry_runs/2026-08-04_local_reach_sweep_dev02_04_08/selected_candidate_profile.json | validation/binary_phase_detector_v25_geometry_runs/2026-08-04_local_reach_sweep_dev02_04_08/selected_candidate_profile.json | validation/binary_phase_detector_v25_geometry_runs/2026-08-04_local_reach_sweep_dev02_04_08/selected_candidate_profile.json | validation/binary_phase_detector_v25_geometry_runs/2026-08-04_local_reach_sweep_dev02_04_08/selected_candidate_profile.json |
| Blocco binary_phase: contratto eventi | grf.binary_phase_event_contract_id | <absent> | <absent> | <absent> | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 |
| Blocco binary_phase: policy eventi invalidi | grf.binary_phase_invalid_event_policy | <absent> | <absent> | <absent> | reject_continue | reject_continue | reject_continue | reject_continue | reject_continue | reject_continue |
| Blocco binary_phase: versione FSM attore | grf.binary_phase_actor_fsm_version | <absent> | <absent> | <absent> | <absent> | <absent> | <absent> | v3 | v2 | v3 |
| Penetrazione: soglia penalita [m] | simulation.grf_penetration_penalty_threshold_m | <absent> | 0.015 | 0.015 | 0.02 | 0.02 | 0.02 | 0.02 | 0.02 | 0.02 |
| Penetrazione: terminazione [m] | simulation.grf_penetration_termination_m | <absent> | 0.025 | 0.025 | 0.028 | 0.028 | 0.028 | 0.028 | 0.028 | 0.028 |
| Timeout swing hard [s] | reward.phase_swing_hard_timeout_s | <absent> | 1.1 | 1.1 | 2.6 | 2.6 | 2.6 | 2.6 | 2.6 | 2.6 |
| Timeout stance hard [s] | reward.phase_stance_hard_timeout_s | <absent> | 2.2 | 2.2 | 2.2 | 2.2 | 2.2 | 2.2 | 2.2 | 2.2 |
| Morphology: profilo | reward.morphology_profile | <absent> | morphology_profiles/ab06_prosthetic_mean_std_corridor.json | morphology_profiles/ab06_prosthetic_mean_std_corridor.json |  | morphology_profiles/ab06_prosthetic_event_warped_mean_std_corridor.json | morphology_profiles/ab06_prosthetic_event_warped_mean_std_corridor.json | morphology_profiles/ab06_prosthetic_event_warped_mean_std_corridor.json | morphology_profiles/ab06_prosthetic_event_warped_mean_std_corridor.json | morphology_profiles/ab06_prosthetic_event_warped_mean_std_corridor.json |
| Morphology: modalita fase | reward.morphology_phase_mode | <absent> | <absent> | <absent> | legacy_cycle_fraction | event_anchored_causal_delayed_experimental | event_anchored_causal_delayed_experimental | event_anchored_causal_delayed_experimental | event_anchored_causal_delayed_experimental | event_anchored_causal_delayed_experimental |
| Morphology: peso | reward.morphology_weight | <absent> | 0 | 0 | 0 | 0.0025 | 0.0025 | 0.0025 | 0.0025 | 0.0025 |
| Morphology: hard termination | reward.morphology_hard_termination_enabled | <absent> | <absent> | <absent> | 0 | 0 | 0 | 0 | 0 | 0 |
| Morphology: allow_effects sperimentale | reward.morphology_experimental_allow_effects | <absent> | <absent> | <absent> | 0 | 0 | 0 | 0 | 0 | 0 |
| Morphology: allow_effects causale | reward.morphology_causal_allow_effects | <absent> | <absent> | <absent> | 0 | 1 | 1 | 1 | 1 | 1 |
| Morphology: contratto eventi causale | reward.morphology_causal_event_contract_id | <absent> | <absent> | <absent> | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 | binary_point_v25+heel_qualified_fsm_v2 |
| Reward mode | reward.reward_mode | imitation | ex_novo | ex_novo | imitation | ex_novo | ex_novo | ex_novo | ex_novo | ex_novo |
| Exact-start sampling | parallelism.exact_start_sampling | <absent> | <absent> | True | False | True | True | True | True | True |
| Start offset nominale [s] | simulation.episode_start_offset_s | 1 | 1.95687 | 1.95687 | 1 | 1.95687 | 1.95687 | 1.95687 | 1.95687 | 1.95687 |
| Start offset choices | simulation.episode_start_offset_choices_s | <absent> | <absent> | [1.756870983805102, 1.956870983805102, 2.156870983805102] | [] | [1.756870983805102, 1.956870983805102, 2.156870983805102] | [1.756870983805102, 1.956870983805102, 2.156870983805102] | [1.756870983805102, 1.956870983805102, 2.156870983805102] | [1.756870983805102, 1.956870983805102, 2.156870983805102] | [1.756870983805102, 1.956870983805102, 2.156870983805102] |
| Gait clock prescritto esposto | simulation.gait_clock_enable | <absent> | False | False | True | False | False | False | False | False |
| Osservazione diagnostica controller | simulation.include_controller_diagnostic_observation | <absent> | False | False | True | False | False | False | False | False |
| PPO lr | ppo.lr | 0.0001 | 0.0001 | 5e-07 | 0.0001 | 5e-07 | 5e-07 | 5e-07 | 5e-07 | 5e-07 |
| PPO batch | ppo.train_batch_size | 4096 | 4096 | 4608 | 4096 | 4608 | 4608 | 4608 | 4608 | 4608 |
| PPO epoche | ppo.num_epochs | 10 | 10 | 1 | 10 | 1 | 1 | 1 | 1 | 1 |
| PPO clip | ppo.clip_param | 0.2 | 0.2 | 0.05 | 0.2 | 0.05 | 0.05 | 0.05 | 0.05 | 0.05 |
| KL guard max minibatch | supervision.max_minibatch_mean_kl_loss | <absent> | <absent> | 0.01 | None | 0.01 | 0.01 | 0.01 | 0.01 | 0.01 |
| freeze_logstd | model.freeze_logstd | <absent> | False | True | False | True | True | True | True | True |
| freeze_actor | model.freeze_actor | <absent> | True | False | False | True | False | False | False | False |
| num_env_runners | parallelism.num_env_runners | 13 | 13 | 12 | 13 | 12 | 12 | 12 | 12 | 12 |

## Luglio (pilot50) vs B0820 v3: classificazione chiave per chiave

Non isometriche: 7; assenti in luglio (nuove in V26/B0820): 28.

| chiave | luglio pilot50 | B0820 v3 | classe |
|---|---|---|---|
| grf.binary_phase_actor_fsm_version | <absent> | v3 | assente_in_luglio (nuovo in V26/B0820) |
| grf.binary_phase_debounce_s | <absent> | 0.005 | assente_in_luglio (nuovo in V26/B0820) |
| grf.binary_phase_detector_profile | <absent> | validation/binary_phase_detector_v25_geometry_runs/2026-08-04_local_reach_sweep_dev02_04_08/selected_candidate_profile.json | assente_in_luglio (nuovo in V26/B0820) |
| grf.binary_phase_event_contract_id | <absent> | binary_point_v25+heel_qualified_fsm_v2 | assente_in_luglio (nuovo in V26/B0820) |
| grf.binary_phase_fsm_mode | <absent> | binary_active | assente_in_luglio (nuovo in V26/B0820) |
| grf.binary_phase_invalid_event_policy | <absent> | reject_continue | assente_in_luglio (nuovo in V26/B0820) |
| grf.detector_sample_dt_s | <absent> | 0.001 | assente_in_luglio (nuovo in V26/B0820) |
| grf.event_contract_id | <absent> | legacy_events_v1 | assente_in_luglio (nuovo in V26/B0820) |
| grf.online_grf_profile | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_correct_magnitude.json | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json | non_isometrico |
| grf.phase_fsm_input_mode | <absent> | legacy_events | assente_in_luglio (nuovo in V26/B0820) |
| grf.phase_sensor_dwell_s | <absent> | 0.03 | assente_in_luglio (nuovo in V26/B0820) |
| grf.phase_sensor_off_threshold_n | <absent> | 2 | assente_in_luglio (nuovo in V26/B0820) |
| grf.phase_sensor_on_threshold_n | <absent> | 5 | assente_in_luglio (nuovo in V26/B0820) |
| logging.progress | False | False | isometric (non-runtime: contabilita/logging) |
| model.primary_split_v25_residual_init_seed | <absent> | None | assente_in_luglio (nuovo in V26/B0820) |
| model.primary_split_v25_residual_input_mean | <absent> | None | assente_in_luglio (nuovo in V26/B0820) |
| model.primary_split_v25_residual_input_std | <absent> | None | assente_in_luglio (nuovo in V26/B0820) |
| model.primary_split_v25_residual_limits | <absent> | None | assente_in_luglio (nuovo in V26/B0820) |
| model.rl_module_kind | <absent> | standard | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_causal_allow_effects | <absent> | 1 | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_causal_event_contract_id | <absent> | binary_point_v25+heel_qualified_fsm_v2 | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_causal_max_samples | <absent> | 4096 | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_completed_segment_max_samples | <absent> | 4096 | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_experimental_allow_effects | <absent> | 0 | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_hard_q_max | <absent> | [0.0, 0.6] | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_hard_q_min | <absent> | [-1.4, -0.6] | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_hard_termination_enabled | <absent> | 0 | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_max_delivery_latency_s | <absent> | 0.01 | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_phase_mode | <absent> | event_anchored_causal_delayed_experimental | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_profile | morphology_profiles/ab06_prosthetic_mean_std_corridor.json | morphology_profiles/ab06_prosthetic_event_warped_mean_std_corridor.json | non_isometrico |
| reward.morphology_reward_delay_s | <absent> | 0.04 | assente_in_luglio (nuovo in V26/B0820) |
| reward.morphology_weight | 0 | 0.0025 | non_isometrico |
| reward.phase_swing_hard_timeout_s | 1.1 | 2.6 | non_isometrico |
| simulation.grf_penetration_penalty_threshold_m | 0.015 | 0.02 | non_isometrico |
| simulation.grf_penetration_termination_m | 0.025 | 0.028 | non_isometrico |
| simulation.iterations | 51 | 55 | non_isometrico (non-runtime: contabilita/logging) |

## B0820 v2 (from_zero) vs B0820 v3 (fixedcorridor): differenze

| chiave | v2 | v3 |
|---|---|---|
| grf.binary_phase_actor_fsm_version | <absent> | v3 |

Nota: la run v2 e la run v3 condividono lo stesso resolved yaml salvo `binary_phase_actor_fsm_version`; la correzione del corridoio causale (tolleranza 1e-12 -> 1e-9, ri-armo sui repair) e' una differenza di **codice**, non di configurazione, e separa le due run insieme alla FSM.
