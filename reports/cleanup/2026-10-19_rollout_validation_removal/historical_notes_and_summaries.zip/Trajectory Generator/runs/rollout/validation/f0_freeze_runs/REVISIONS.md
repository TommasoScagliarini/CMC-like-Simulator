# Revisioni degli artefatti della Fase 0 (piano 2026-08-22)

| revisione | directory | stato | motivo |
|---|---|---|---|
| r1 | `2026-08-22_F0_freeze_inventory_baseline/` | SUPERSEDED | modulo embedded errato (MultiRLModule vuoto), contatori lifetime sommati, nessuna verifica receipt |
| r2 | `2026-08-22_F0_freeze_inventory_baseline_r2/` | SUPERSEDED | generata prima del secondo audit: status ok lasco, nessun ricalcolo digest output, nessun preflight sincrono, "riproduzione" impropria, riferimenti storici senza SHA, tree digest host-specific, self-test vacuo |
| r3 | `2026-08-22_F0_freeze_inventory_baseline_r3/` | CANDIDATA al Gate F0 | tutte le correzioni dell'audit integrate; artefatti statici e manifest dry-run rigenerati; nessun rollout eseguito |

Regola: nessuna revisione viene sovrascritta; ogni nuova revisione e' una directory nuova. Solo la revisione candidata viene sottoposta all'audit del gate.
