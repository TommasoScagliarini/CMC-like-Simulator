# F0 — Censimento separato delle due run B0820 — revisione r3

Generato: 2026-08-22T17:10:31+00:00 — git HEAD `04c0c470da81`.

Chiarimento sul nome: `MLP_ExNovo_B0820_from_zero_50iter` **non** e' un'inizializzazione casuale: riprende `checkpoint_last` del critic warmup (actor trapiantato 39->35 + critic caldo, iterazione logica 5) ed e' la run con FSM attore v2 e corridoio causale pre-fix. `MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter` riprende lo stesso checkpoint con FSM v3 e corridoio corretto (la correzione del corridoio e' una differenza di codice, non di yaml).

Semantica dei contatori di terminazione: RLlib lifetime counters restored from the warmup checkpoint; never summed across iterations. Reported: lifetime at resume (warmup last row), lifetime of the final row, delta_over_run = final - resume, and per-row delta versus the previous row; first-row delta is measured against warmup last row.

| voce | MLP_ExNovo_B0820_from_zero_50iter | MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter |
|---|---|---|
| resume_from | /Users/tommy/Documents/CMC-like-Simulator - Claude/validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/checkpoint_last | /Users/tommy/Documents/CMC-like-Simulator - Claude/validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/checkpoint_last |
| riprende il warmup (non init casuale) | True | True |
| initialization_mode (summary) | resume_from | resume_from |
| restored_logical_iteration | 5 | 5 |
| iterazioni logiche nel jsonl | 6, 55 | 6, 55 |
| righe jsonl | 50 | 50 |
| env steps sampled lifetime prima/ultima riga | 27648, 253440 | 27648, 253440 |
| delta env steps per iterazione (valori unici) | 4608 | 4608 |
| FSM attore (resolved) | <absent -> v2 behaviour at that code revision> | v3 |
| policy eventi invalidi | reject_continue | reject_continue |
| morphology_weight | 0.0025 | 0.0025 |
| inizio | 2026-08-20T22:25:48+02:00 | 2026-08-21T17:20:24+02:00 |
| fine | 2026-08-21T05:55:06+02:00 | 2026-08-22T00:13:06+02:00 |
| wall time [s] | 26954.8 | 24759 |
| stop | completed | completed |
| supervisor restart/crash | status=completed; restart_count=0; skipped_iterations=[]; consecutive_skips=0; crash_restart_count=0; consecutive_crash_restarts=0; resume_from=/Users/tommy/Documents/CMC-like-Simulator - Claude/validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/checkpoint_last | status=completed; restart_count=0; skipped_iterations=[]; consecutive_skips=0; crash_restart_count=0; consecutive_crash_restarts=0; resume_from=/Users/tommy/Documents/CMC-like-Simulator - Claude/validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/checkpoint_last |
| env_runner_restart_audit.json presente | False | False |
| iterazioni senza episodio completato (return None) |  | 6 |
| primo return valido (iter, val) | 6, -18.2914 | 7, -80.9971 |
| return ultima | 55, -35.3983 | 55, -76.5159 |
| return min (iter, val) | 15, -44.1662 | 10, -230.501 |
| return max (iter, val) | 33, -11.949 | 39, -18.9502 |
| media return prime 10 valide | -29.0223 | -139.006 |
| media return ultime 10 valide | -27.6269 | -95.237 |
| best (meta) | logical_iteration=33; rllib_training_iteration=33 | logical_iteration=39; rllib_training_iteration=39 |
| last (meta) | logical_iteration=55; rllib_training_iteration=55 | logical_iteration=55; rllib_training_iteration=55 |
| KL max minibatch: max sulle iterazioni | 1.48529e-05 | 5.70181e-06 |
| KL coeff prima/ultima | 0.5, 8.88178e-16 | 0.5, 8.88178e-16 |
| entropia min/max [nat] | 1.07812, 1.724 | 1.34565, 2.15193 |
| sigma equivalente min/max | 0.414833, 0.57296 | 0.474205, 0.709658 |
| exact-start balance PASS | 50 | 50 |
| learner batch PASS | 50 | 50 |
| KL guard PASS | 50 | 50 |
| terminazioni: chiavi (ordinate) | episode_time_limit, grf_penetration, morphology_causal_contract_failure, phase_timeout_stance | episode_time_limit, grf_penetration, morphology_causal_contract_failure, phase_timeout_stance, phase_timeout_swing |
| terminazioni: lifetime alla ripresa (ultima riga warmup) | episode_time_limit=10; grf_penetration=1; morphology_causal_contract_failure=22; phase_timeout_stance=22 | episode_time_limit=10; grf_penetration=1; morphology_causal_contract_failure=22; phase_timeout_stance=22; phase_timeout_swing=0 |
| terminazioni: lifetime prima riga della run | episode_time_limit=10; grf_penetration=1; morphology_causal_contract_failure=26; phase_timeout_stance=24 | episode_time_limit=10; grf_penetration=1; morphology_causal_contract_failure=22; phase_timeout_stance=22; phase_timeout_swing=None |
| terminazioni: delta prima riga vs ultima riga warmup | episode_time_limit=0; grf_penetration=0; morphology_causal_contract_failure=4; phase_timeout_stance=2 | episode_time_limit=0; grf_penetration=0; morphology_causal_contract_failure=0; phase_timeout_stance=0; phase_timeout_swing=0 |
| terminazioni: lifetime finale (ultima riga) | episode_time_limit=87; grf_penetration=5; morphology_causal_contract_failure=298; phase_timeout_stance=291 | episode_time_limit=393; grf_penetration=10; morphology_causal_contract_failure=42; phase_timeout_stance=22; phase_timeout_swing=73 |
| terminazioni: delta run = lifetime finale - lifetime alla ripresa | episode_time_limit=77; grf_penetration=4; morphology_causal_contract_failure=276; phase_timeout_stance=269 | episode_time_limit=383; grf_penetration=9; morphology_causal_contract_failure=20; phase_timeout_stance=0; phase_timeout_swing=73 |
| advantage start -0.20, prima riga | iteration=6; advantage_positive_fraction=0.9902; advantage_mean=0.189; completed_episodes=2 | iteration=6; advantage_positive_fraction=1; advantage_mean=0.3253; completed_episodes=0 |

## Andamento per iterazione (return medio, KL max minibatch, entropia, delta terminazioni vs riga precedente; prima riga vs ultima riga warmup)

### MLP_ExNovo_B0820_from_zero_50iter

| iter | return | len | KL max mb | KL coeff | entropia | vf_loss | vf_expl_var | exact-start | Δ time_limit | Δ stance_to | Δ swing_to | Δ contract_fail | Δ penetr | adv+ frac -0.20 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 6 | -18.29 | 310.7 | 1.49e-05 | 0.5 | 1.599 | 1.91 | -0.00753 | True | 0 | 2 | 0 | 4 | 0 | 0.990 |
| 7 | -18.4 | 439.7 | 1.21e-06 | 0.25 | 1.152 | 0.5232 | -0.013 | True | 3 | 4 | 0 | 3 | 0 | 0.895 |
| 8 | -43.22 | 384.7 | 1.13e-06 | 0.125 | 1.343 | 0.01454 | -0.735 | True | 1 | 8 | 0 | 5 | 0 | 0.842 |
| 9 | -19.08 | 426.6 | 2.57e-06 | 0.0625 | 1.423 | 1.281 | 0.00319 | True | 7 | 3 | 0 | 3 | 0 | 0.863 |
| 10 | -32.83 | 374.4 | 4.63e-07 | 0.0312 | 1.407 | 1.541 | 0.000838 | True | 0 | 5 | 0 | 6 | 0 | 0.904 |
| 11 | -37.41 | 395 | 3.34e-06 | 0.0156 | 1.078 | 1.938 | -0.00654 | True | 2 | 6 | 0 | 4 | 0 | 0.868 |
| 12 | -26.6 | 363.8 | 2.32e-06 | 0.00781 | 1.147 | 1.873 | -0.0132 | True | 0 | 7 | 0 | 7 | 0 | 0.930 |
| 13 | -22.68 | 335.8 | 3.82e-06 | 0.00391 | 1.144 | 0.02834 | -0.407 | True | 0 | 5 | 0 | 8 | 0 | 0.878 |
| 14 | -27.54 | 353.1 | 6.47e-07 | 0.00195 | 1.177 | 2.34 | -0.0115 | True | 1 | 5 | 0 | 5 | 0 | 0.826 |
| 15 | -44.17 | 356 | 1.47e-06 | 0.000977 | 1.312 | 2.323 | -0.013 | True | 2 | 8 | 0 | 3 | 2 | 0.805 |
| 16 | -31.65 | 367.3 | 4.6e-07 | 0.000488 | 1.244 | 0.7116 | -0.0181 | True | 2 | 4 | 0 | 8 | 0 | 0.844 |
| 17 | -24.8 | 380.4 | 1.84e-06 | 0.000244 | 1.373 | 0.06775 | -0.094 | True | 1 | 5 | 0 | 7 | 0 | 0.900 |
| 18 | -23.75 | 338.6 | 6.15e-07 | 0.000122 | 1.724 | 1.441 | 0.0342 | True | 1 | 5 | 0 | 6 | 0 | 0.997 |
| 19 | -20.41 | 368.5 | 7.98e-07 | 6.1e-05 | 1.411 | 0.02763 | -0.19 | True | 2 | 5 | 0 | 7 | 0 | 0.963 |
| 20 | -28.23 | 353.9 | 9e-07 | 3.05e-05 | 1.216 | 2.581 | -0.0118 | True | 1 | 6 | 0 | 5 | 0 | 0.861 |
| 21 | -43.77 | 377.5 | 1.63e-06 | 1.53e-05 | 1.184 | 2.429 | -0.0132 | True | 2 | 8 | 0 | 2 | 1 | 0.820 |
| 22 | -34.72 | 360.5 | 2.05e-06 | 7.63e-06 | 1.505 | 2.004 | -0.00236 | True | 0 | 8 | 0 | 5 | 0 | 0.869 |
| 23 | -31.91 | 386.6 | 1.4e-06 | 3.81e-06 | 1.396 | 1.125 | -0.00737 | True | 2 | 5 | 0 | 4 | 0 | 0.829 |
| 24 | -36.31 | 387.1 | 1.75e-06 | 1.91e-06 | 1.716 | 0.1503 | 0.012 | True | 2 | 5 | 0 | 4 | 0 | 0.860 |
| 25 | -28.7 | 392.8 | 5.46e-07 | 9.54e-07 | 1.233 | 1.304 | -0.00929 | True | 2 | 5 | 0 | 7 | 0 | 0.941 |
| 26 | -17.04 | 395.4 | 5.42e-06 | 4.77e-07 | 1.168 | 1.308 | -0.0119 | True | 3 | 4 | 0 | 4 | 0 | 0.971 |
| 27 | -40.59 | 395.8 | 3.29e-06 | 2.38e-07 | 1.52 | 3.419 | -0.00786 | True | 3 | 7 | 0 | 2 | 0 | 0.817 |
| 28 | -21.65 | 372.4 | 5.68e-06 | 1.19e-07 | 1.122 | 1.292 | -0.0131 | True | 1 | 4 | 0 | 8 | 0 | 0.861 |
| 29 | -35.22 | 330.8 | 2.31e-06 | 5.96e-08 | 1.311 | 0.03053 | -0.0614 | True | 0 | 7 | 0 | 7 | 0 | 0.904 |
| 30 | -35.26 | 396.9 | 1.42e-06 | 2.98e-08 | 1.184 | 0.0455 | -0.0826 | True | 2 | 6 | 0 | 3 | 0 | 0.880 |
| 31 | -24.64 | 367.6 | 4.62e-07 | 1.49e-08 | 1.461 | 0.3842 | -0.0222 | True | 2 | 4 | 0 | 6 | 0 | 0.911 |
| 32 | -15.92 | 348.8 | 8.81e-07 | 7.45e-09 | 1.369 | 0.7028 | -0.0296 | True | 2 | 4 | 0 | 8 | 0 | 0.994 |
| 33 | -11.95 | 345.7 | 1.79e-06 | 3.73e-09 | 1.655 | 1.502 | -0.00725 | True | 2 | 3 | 0 | 9 | 0 | 0.905 |
| 34 | -21.71 | 380.1 | 5.63e-06 | 1.86e-09 | 1.416 | 0.6253 | -0.0208 | True | 2 | 6 | 0 | 7 | 0 | 0.981 |
| 35 | -27.18 | 340.2 | 4.34e-07 | 9.31e-10 | 1.182 | 1.903 | -0.0082 | True | 0 | 6 | 0 | 7 | 0 | 0.847 |
| 36 | -25.87 | 335.5 | 4.7e-07 | 4.66e-10 | 1.499 | 0.835 | 0.0385 | True | 0 | 5 | 0 | 6 | 0 | 0.940 |
| 37 | -31.14 | 386.2 | 3.59e-07 | 2.33e-10 | 1.326 | 0.586 | -0.0141 | True | 1 | 7 | 0 | 4 | 0 | 0.824 |
| 38 | -30.86 | 383.9 | 4.26e-07 | 1.16e-10 | 1.276 | 0.01932 | -0.06 | True | 2 | 6 | 0 | 4 | 0 | 0.862 |
| 39 | -15.39 | 356.5 | 4.56e-06 | 5.82e-11 | 1.4 | 0.01809 | -0.159 | True | 1 | 4 | 0 | 9 | 0 | 0.894 |
| 40 | -31.83 | 364.7 | 1.47e-06 | 2.91e-11 | 1.314 | 0.0231 | -0.024 | True | 1 | 6 | 0 | 5 | 0 | 0.827 |
| 41 | -42.64 | 371 | 1.93e-06 | 1.46e-11 | 1.34 | 0.02107 | 0.0132 | True | 1 | 8 | 0 | 4 | 0 | 0.905 |
| 42 | -19.73 | 387.9 | 1.93e-06 | 7.28e-12 | 1.189 | 1.807 | -0.00992 | True | 4 | 3 | 0 | 5 | 0 | 0.818 |
| 43 | -19.08 | 361.7 | 2.32e-06 | 3.64e-12 | 1.227 | 0.6587 | -0.0227 | True | 2 | 4 | 0 | 6 | 0 | 0.867 |
| 44 | -37.21 | 364.3 | 8.25e-07 | 1.82e-12 | 1.413 | 1.239 | -0.0019 | True | 1 | 6 | 0 | 6 | 0 | 0.857 |
| 45 | -29.6 | 373.9 | 1.22e-06 | 9.09e-13 | 1.378 | 0.02414 | -0.0764 | True | 1 | 6 | 0 | 6 | 0 | 0.922 |
| 46 | -34.64 | 376.6 | 9.09e-07 | 4.55e-13 | 1.378 | 0.01282 | -0.0986 | True | 0 | 8 | 0 | 5 | 0 | 0.854 |
| 47 | -23.73 | 365.2 | 1.41e-06 | 2.27e-13 | 1.605 | 0.1508 | -0.0238 | True | 2 | 4 | 0 | 7 | 0 | 0.896 |
| 48 | -35.71 | 389.4 | 9.34e-07 | 1.14e-13 | 1.454 | 1.734 | 0.000346 | True | 2 | 7 | 0 | 3 | 0 | 0.899 |
| 49 | -13.09 | 378.1 | 8.55e-07 | 5.68e-14 | 1.376 | 1.303 | 0.00951 | True | 0 | 2 | 0 | 7 | 0 | 0.865 |
| 50 | -24.82 | 397 | 7.38e-07 | 2.84e-14 | 1.26 | 1.064 | -0.0126 | True | 5 | 5 | 0 | 6 | 0 | 0.909 |
| 51 | -29.45 | 353 | 5.06e-06 | 1.42e-14 | 1.269 | 1.488 | -0.00882 | True | 1 | 6 | 0 | 5 | 0 | 0.893 |
| 52 | -27.62 | 401.5 | 1.12e-06 | 7.11e-15 | 1.241 | 0.02311 | -0.093 | True | 2 | 4 | 0 | 6 | 0 | 0.870 |
| 53 | -30.68 | 368.5 | 3.19e-07 | 3.55e-15 | 1.389 | 0.279 | -0.0219 | True | 0 | 6 | 0 | 6 | 0 | 0.950 |
| 54 | -21.15 | 376.3 | 1.83e-06 | 1.78e-15 | 1.151 | 3.085 | -0.013 | True | 2 | 6 | 0 | 7 | 0 | 0.842 |
| 55 | -35.4 | 385.1 | 1.66e-06 | 8.88e-16 | 1.279 | 2.871 | -0.0119 | True | 1 | 6 | 0 | 5 | 1 | 0.822 |

### MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter

| iter | return | len | KL max mb | KL coeff | entropia | vf_loss | vf_expl_var | exact-start | Δ time_limit | Δ stance_to | Δ swing_to | Δ contract_fail | Δ penetr | adv+ frac -0.20 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 6 | None | None | 2.54e-06 | 0.5 | 1.798 | 1.084 | 0.00756 | True | 0 | 0 | 0 | 0 | 0 | 1.000 |
| 7 | -81 | 500 | 4.25e-06 | 0.25 | 1.541 | 1.884 | -0.00506 | True | 12 | 0 | 0 | 0 | 0 | 0.954 |
| 8 | -167.1 | 469.2 | 2.7e-06 | 0.125 | 1.445 | 0.07949 | -0.0878 | True | 8 | 0 | 4 | 0 | 0 | 0.888 |
| 9 | -108.6 | 486.5 | 6.7e-07 | 0.0625 | 1.652 | 0.7892 | -0.0209 | True | 9 | 0 | 3 | 0 | 0 | 0.971 |
| 10 | -230.5 | 477.7 | 5.79e-07 | 0.0312 | 1.553 | 1.615 | 0.00162 | True | 2 | 0 | 1 | 0 | 0 | 1.000 |
| 11 | -81.19 | 487 | 2.1e-07 | 0.0156 | 1.589 | 1.251 | 0.00348 | True | 10 | 0 | 1 | 0 | 0 | 1.000 |
| 12 | -134.2 | 446.2 | 1.11e-06 | 0.00781 | 1.478 | 2.131 | 0.00153 | True | 9 | 0 | 2 | 0 | 1 | 0.942 |
| 13 | -165.2 | 486.6 | 6.3e-07 | 0.00391 | 1.761 | 4.173 | 0.00101 | True | 8 | 0 | 3 | 0 | 0 | 0.940 |
| 14 | -178.9 | 428.9 | 6.95e-07 | 0.00195 | 1.61 | 3.986 | -0.000169 | True | 4 | 0 | 2 | 2 | 0 | 0.986 |
| 15 | -135.9 | 467.5 | 8.69e-07 | 0.000977 | 1.728 | 2.271 | -0.00276 | True | 7 | 0 | 3 | 0 | 0 | 0.987 |
| 16 | -107.3 | 471.6 | 2.11e-07 | 0.000488 | 1.499 | 2.774 | -0.000351 | True | 8 | 0 | 1 | 1 | 0 | 1.000 |
| 17 | -93.96 | 488.7 | 2.15e-06 | 0.000244 | 1.955 | 1.041 | -0.00911 | True | 9 | 0 | 3 | 0 | 0 | 0.766 |
| 18 | -95.51 | 500 | 4.8e-07 | 0.000122 | 1.542 | 3.646 | 0.00152 | True | 6 | 0 | 0 | 0 | 0 | 0.980 |
| 19 | -78.87 | 485.9 | 7.58e-07 | 6.1e-05 | 1.713 | 3.897 | 0.00303 | True | 9 | 0 | 1 | 0 | 0 | 0.976 |
| 20 | -176.6 | 487.9 | 2.14e-06 | 3.05e-05 | 1.579 | 1.664 | -0.0158 | True | 9 | 0 | 1 | 0 | 0 | 0.955 |
| 21 | -101.8 | 458.7 | 2.72e-06 | 1.53e-05 | 1.515 | 1.582 | -0.0024 | True | 9 | 0 | 2 | 1 | 0 | 0.911 |
| 22 | -52.77 | 484.5 | 4.28e-06 | 7.63e-06 | 1.772 | 2.018 | -0.00333 | True | 10 | 0 | 0 | 1 | 0 | 0.880 |
| 23 | -65.05 | 413.3 | 7.13e-07 | 3.81e-06 | 1.734 | 2.49 | -0.0019 | True | 4 | 0 | 0 | 2 | 0 | 0.945 |
| 24 | -123.7 | 481.2 | 5.06e-07 | 1.91e-06 | 1.513 | 3.405 | 0.00468 | True | 8 | 0 | 2 | 0 | 0 | 0.979 |
| 25 | -75.41 | 470.8 | 3.54e-06 | 9.54e-07 | 1.469 | 0.5994 | -0.0208 | True | 11 | 0 | 1 | 0 | 1 | 1.000 |
| 26 | -122.2 | 500 | 5.7e-06 | 4.77e-07 | 1.488 | 1.505 | 0.000249 | True | 10 | 0 | 0 | 0 | 0 | 0.881 |
| 27 | -135.3 | 412.5 | 3.71e-06 | 2.38e-07 | 1.654 | 1.005 | -0.00571 | True | 3 | 0 | 2 | 0 | 1 | 1.000 |
| 28 | -111.4 | 479.7 | 1.6e-07 | 1.19e-07 | 1.558 | 1.838 | 0.00313 | True | 7 | 0 | 2 | 0 | 0 | 1.000 |
| 29 | -102.9 | 461.4 | 5.33e-07 | 5.96e-08 | 1.389 | 0.01895 | -0.45 | True | 9 | 0 | 3 | 1 | 0 | 1.000 |
| 30 | -84.43 | 462.3 | 5.16e-07 | 2.98e-08 | 1.891 | 2.071 | -0.00484 | True | 8 | 0 | 3 | 0 | 1 | 0.986 |
| 31 | -114 | 472.1 | 1.47e-07 | 1.49e-08 | 1.615 | 1.718 | 0.0174 | True | 6 | 0 | 1 | 1 | 0 | 1.000 |
| 32 | -21.61 | 500 | 5.87e-07 | 7.45e-09 | 1.869 | 1.977 | 0.0158 | True | 9 | 0 | 0 | 0 | 0 | 0.981 |
| 33 | -30.37 | 500 | 5.23e-07 | 3.73e-09 | 1.442 | 0.6935 | -0.0029 | True | 8 | 0 | 0 | 0 | 0 | 0.907 |
| 34 | -122.9 | 472.5 | 6.8e-07 | 1.86e-09 | 1.552 | 0.7258 | 0.00198 | True | 8 | 0 | 3 | 2 | 0 | 0.801 |
| 35 | -104.8 | 498 | 3.05e-07 | 9.31e-10 | 1.568 | 1.225 | 0.00418 | True | 10 | 0 | 1 | 0 | 0 | 0.824 |
| 36 | -42.85 | 453 | 1.79e-06 | 4.66e-10 | 1.537 | 3.398 | -0.000837 | True | 5 | 0 | 0 | 0 | 1 | 0.813 |
| 37 | -91.23 | 446.8 | 1.84e-06 | 2.33e-10 | 1.564 | 2.737 | 0.0015 | True | 8 | 0 | 1 | 2 | 0 | 0.918 |
| 38 | -112.8 | 432.2 | 9.39e-07 | 1.16e-10 | 1.563 | 2.947 | 0.000673 | True | 8 | 0 | 3 | 1 | 1 | 1.000 |
| 39 | -18.95 | 500 | 1.82e-06 | 5.82e-11 | 1.857 | 4.186 | -0.00111 | True | 11 | 0 | 0 | 0 | 0 | 1.000 |
| 40 | -184.1 | 470.8 | 3.66e-06 | 2.91e-11 | 1.595 | 4.158 | 0.000246 | True | 5 | 0 | 3 | 0 | 0 | 0.989 |
| 41 | -146.1 | 431 | 1.69e-06 | 1.46e-11 | 1.346 | 2.409 | -0.00204 | True | 6 | 0 | 3 | 0 | 1 | 1.000 |
| 42 | -109.2 | 464.8 | 7.47e-07 | 7.28e-12 | 2.152 | 3.895 | 0.00342 | True | 5 | 0 | 3 | 1 | 0 | 0.982 |
| 43 | -77.86 | 488.1 | 4.77e-07 | 3.64e-12 | 1.722 | 2.6 | 0.002 | True | 11 | 0 | 1 | 0 | 0 | 0.980 |
| 44 | -73.59 | 500 | 1.71e-06 | 1.82e-12 | 1.602 | 2.271 | -0.00127 | True | 9 | 0 | 0 | 0 | 0 | 1.000 |
| 45 | -114.7 | 426.1 | 1.02e-06 | 9.09e-13 | 1.995 | 1.027 | -0.00309 | True | 4 | 0 | 2 | 1 | 1 | 1.000 |
| 46 | -68.66 | 500 | 1.43e-06 | 4.55e-13 | 1.519 | 1.335 | -0.00698 | True | 10 | 0 | 0 | 0 | 0 | 1.000 |
| 47 | -51.83 | 500 | 1.58e-06 | 2.27e-13 | 1.591 | 1.111 | 0.00547 | True | 11 | 0 | 0 | 0 | 0 | 1.000 |
| 48 | -90.3 | 481 | 6.65e-07 | 1.14e-13 | 1.498 | 2.521 | 0.000642 | True | 8 | 0 | 2 | 0 | 0 | 1.000 |
| 49 | -69.42 | 425.1 | 9.21e-07 | 5.68e-14 | 1.61 | 1.828 | 0.0216 | True | 6 | 0 | 1 | 2 | 0 | 0.843 |
| 50 | -159.9 | 439.6 | 1.68e-06 | 2.84e-14 | 1.496 | 0.7535 | -0.00904 | True | 6 | 0 | 2 | 1 | 1 | 1.000 |
| 51 | -150.5 | 485.4 | 1.71e-06 | 1.42e-14 | 1.565 | 0.8124 | -0.00153 | True | 9 | 0 | 3 | 0 | 0 | 0.978 |
| 52 | -117.6 | 475.7 | 8.98e-07 | 7.11e-15 | 1.447 | 1.64 | 0.0114 | True | 8 | 0 | 2 | 0 | 0 | 0.955 |
| 53 | -100.3 | 491.2 | 2.88e-07 | 3.55e-15 | 1.633 | 4.701 | -1.62e-05 | True | 8 | 0 | 1 | 0 | 0 | 0.943 |
| 54 | -67.42 | 486.2 | 1.11e-06 | 1.78e-15 | 1.699 | 1.982 | -0.00851 | True | 8 | 0 | 1 | 0 | 0 | 0.928 |
| 55 | -76.52 | 481.9 | 1.92e-06 | 8.88e-16 | 1.493 | 1.513 | -0.0065 | True | 7 | 0 | 0 | 1 | 0 | 0.872 |
