# Analisi frozen-policy H0 dopo la separazione GRF/detector

Data: 2026-07-23

Stato: diagnostico, non promuovibile. I casi V13 costituiscono un'eccezione
diagnostica esplicitamente richiesta e non autorizzano runtime, inference
ordinaria o training con V13.

## Protocollo comune

- policy: H0 canonica, `rl_module_last`, iterazione logica 1;
- selezione azione: deterministica;
- seed: `123`;
- start offset: `1.956870983805102 s`;
- durata richiesta: `5 s`, massimo `500` step;
- durata segmento: `0.01 s`;
- GRF primaria e lato applicato: identici nei tre casi;
- Morphology Corridor: peso `0`;
- output fisici e policy trace: attivi.

Il protocollo con path e hash è in
`validation/postrouting_frozen_ablation_protocol_2026-07-23.json`.

## Risultati

| Caso | Detector | FSM | Step | Return | Penetrazione max | HS validi | TO validi | Cicli | Fine |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| 1 | storico | `legacy_events` | 35 | -2,233269635 | 25,395 mm | 1 | 0 | 0 | `grf_penetration` |
| 2 | V13 | `legacy_events` | 35 | -2,233269635 | 25,395 mm | 1 | 0 | 0 | `grf_penetration` |
| 3 | V13 | `two_sensor` | 35 | -2,232333670 | 25,659 mm | 1 | 0 | 0 | `grf_penetration` |

Tutti i watchdog sono terminati con `returncode=0`, senza timeout. Ogni trace
contiene 35 decisioni policy e ogni file online-GRF contiene 350 campioni
fisici a 1 ms.

## Caso 1 → caso 2: effetto della geometria V13 in legacy

Nei 35 step disponibili sono identici bit-per-bit:

- tutte le 35 feature actor;
- azioni raw e applicate;
- riferimento servito;
- cinematica e stati;
- output SEA;
- GRF primaria;
- reward terms e return;
- istante e causa di terminazione.

Le letture locali del detector sono invece differenti, come previsto. Al primo
step:

- detector storico sinistro: `64,467 N` aggregati;
- detector V13 sinistro: `32,873 N` aggregati;
- feature actor dalla GRF primaria: `0 BW`, `in_contact=0` in entrambi.

Questo è un riscontro closed-loop della separazione appena introdotta: cambiare
le sfere detector non modifica più carico/contact fisici dell'actor.

L'evento destro TO legacy cambia di 11 ms perché V13 è left-only e il lato
destro usa ora correttamente la GRF primaria. Il cambiamento resta nel flusso
privilegiato/diagnostico e non modifica actor o dinamica in questa finestra.

Conclusione limitata: V13 non è la causa del collasso osservato in modalità
legacy nei primi 0,35 s. Non è una validazione completa di V13, perché il
rollout non raggiunge alcun TO sinistro o ciclo completo.

## Caso 2 → caso 3: effetto di `two_sensor`

Il detector two-sensor conferma l'HS di startup prima del legacy:

| Segnale | Legacy | Two-sensor |
|---|---:|---:|
| step di accettazione FSM | 6 | 4 |
| pulse HS visibile all'actor | 7 | 5 |
| tempo del pulse actor | 14,016871 s | 13,996871 s |

La prima divergenza dell'actor e delle azioni compare allo step 5. In quel
passaggio, `two_sensor - legacy` vale:

```text
azione ginocchio = -0,0229700 rad
azione caviglia  = -0,0332657 rad
```

Sui 35 step:

```text
RMSE azioni               = 0,0124381 rad
massimo errore azione     = 0,0332657 rad
RMSE cinematica protesica = 0,0061506 rad
massimo errore cinematico = 0,0137598 rad
```

`two_sensor` aumenta la penetrazione massima di `0,2636 mm`, ma termina allo
stesso step. Il piccolo miglioramento del return (`+0,000936`) non rappresenta
un miglioramento di stabilità.

## Evidenza sul problema principale

Il riferimento più importante è il caso 1: anche H0 con il vecchio detector,
`legacy_events` e corridor disattivato collassa dopo 0,35 s. V13 e
`two_sensor` non sono quindi necessari per produrre il fallimento post-routing.

Nel caso 1:

- il detector è già in contatto dal primo step;
- la GRF primaria applicata dichiara il primo contatto a `14,119871 s`;
- l'actor vede `in_contact=1` soltanto allo step 19, `14,136871 s`;
- la forza primaria supera 20 N a `14,155871 s`;
- l'HS legacy ha event time `13,946871 s`.

H0 riceve quindi l'HS mentre il nuovo input fisico è ancora quasi nullo:
circa `4×10⁻⁷ BW`, con `in_contact=0`. Il contatto fisico compare
circa 120 ms dopo la decisione HS legacy; con `two_sensor` il distacco temporale
sale a circa 140 ms.

Prima della correzione, H0 avrebbe ricevuto nello stesso campo l'aggregato
detector e `in_contact=1`. Lo shift dell'observation è dunque reale e ampio:
nei primi 35 step il detector risulta in contatto 35/35 volte, mentre la GRF
primaria soltanto 18/35.

## Confronto storico

Il rollout H0 storico del 2026-07-14, con lo stesso checkpoint, start, seed,
profili, observation schema, soglia di penetrazione e tutti i reward field
comuni, aveva ottenuto:

```text
step                    500
return                  51,797496
penetrazione massima    23,960 mm
cicli validi            2
fine                    episode_time_limit
```

Il nuovo riferimento post-routing ottiene 35 step e termina per penetrazione.
Questo è coerente con un'incompatibilità comportamentale di H0 rispetto alla
nuova semantica load/contact. Non costituisce però una prova causale assoluta:
lo storico non contiene un policy trace e il sorgente runtime complessivo è
cambiato nel tempo. Un quarto rollout closed-loop che riproduca temporaneamente
il solo routing precedente sarebbe necessario per una chiusura causale
strettamente controllata.

## Decisione

I tre punti richiesti sono completati, ma il gate preliminare fallisce:

- nessun caso raggiunge un Toe Off sinistro;
- nessun caso completa un ciclo;
- il riferimento post-routing non è stabile.

Non è quindi giustificato procedere ora con corridor `0.05` o con un nuovo
training. Prima occorre:

1. verificare se il ritardo di contatto della GRF primaria rispetto all'HS è
   fisicamente corretto o dipende dalla geometria/inizializzazione del
   generatore online di GRF;
2. solo dopo, adattare o ricostruire H0 usando le feature load/contact della GRF
   primaria;
3. ripetere la matrice fino ad almeno un TO sinistro e due cicli completi.

## Artefatti

- `case01_old_legacy_corridor0/`
- `case02_v13_legacy_corridor0/`
- `case03_v13_twosensor_corridor0/`
- `comparison_case01_vs_case02.json`
- `comparison_case02_vs_case03.json`

