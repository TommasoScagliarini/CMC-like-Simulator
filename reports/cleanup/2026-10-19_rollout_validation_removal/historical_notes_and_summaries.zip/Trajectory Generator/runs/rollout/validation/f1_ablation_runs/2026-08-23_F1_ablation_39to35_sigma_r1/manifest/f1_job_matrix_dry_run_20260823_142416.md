# F1 job matrix — dry-run 20260823_142416

Protocol SHA-256: `5d51b700347d612be750c1397dea5f6e16e2fc96c26b4f067e80ed3491d5b82a` — runtime `v3_canonical` config `a870cc38a77d…` — git HEAD `04c0c470da81`

Jobs: 53 (pending module: 33); reconstruction config keys equal: True; sealed seed found: False

| job_id | family | stage | candidate | class | start | sel | seed | driver | adapter | module pending | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A_ISO39_V3__v3_canonical__minus020__det | aiso_det | 1 | A_ISO39_V3 | isometric_privileged_39D | minus020 | deterministic | 123 | f1_rollout_aiso | aiso4 | False | True |
| A_ISO39_V3__v3_canonical__nominal__det | aiso_det | 1 | A_ISO39_V3 | isometric_privileged_39D | nominal | deterministic | 123 | f1_rollout_aiso | aiso4 | False | True |
| A_ISO39_V3__v3_canonical__plus020__det | aiso_det | 1 | A_ISO39_V3 | isometric_privileged_39D | plus020 | deterministic | 123 | f1_rollout_aiso | aiso4 | False | True |
| A_ISO39_V3_S005__v3_canonical__minus020__stoch_seed123 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | minus020 | stochastic | 123 | f1_rollout_aiso | aiso4 | True | True |
| A_ISO39_V3_S005__v3_canonical__minus020__stoch_seed124 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | minus020 | stochastic | 124 | f1_rollout_aiso | aiso4 | True | True |
| A_ISO39_V3_S005__v3_canonical__minus020__stoch_seed125 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | minus020 | stochastic | 125 | f1_rollout_aiso | aiso4 | True | True |
| A_ISO39_V3_S005__v3_canonical__nominal__stoch_seed123 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | nominal | stochastic | 123 | f1_rollout_aiso | aiso4 | True | True |
| A_ISO39_V3_S005__v3_canonical__nominal__stoch_seed124 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | nominal | stochastic | 124 | f1_rollout_aiso | aiso4 | True | True |
| A_ISO39_V3_S005__v3_canonical__nominal__stoch_seed125 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | nominal | stochastic | 125 | f1_rollout_aiso | aiso4 | True | True |
| A_ISO39_V3_S005__v3_canonical__plus020__stoch_seed123 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | plus020 | stochastic | 123 | f1_rollout_aiso | aiso4 | True | True |
| A_ISO39_V3_S005__v3_canonical__plus020__stoch_seed124 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | plus020 | stochastic | 124 | f1_rollout_aiso | aiso4 | True | True |
| A_ISO39_V3_S005__v3_canonical__plus020__stoch_seed125 | aiso_stoch_s005 | 1 | A_ISO39_V3_S005 | isometric_privileged_39D | plus020 | stochastic | 125 | f1_rollout_aiso | aiso4 | True | True |
| B__v3_canonical__minus020__det | b_det | 1 | B | isometric_comparable | minus020 | deterministic | 123 | rollout_eval | None | False | True |
| B__v3_canonical__nominal__det | b_det | 1 | B | isometric_comparable | nominal | deterministic | 123 | rollout_eval | None | False | True |
| B__v3_canonical__plus020__det | b_det | 1 | B | isometric_comparable | plus020 | deterministic | 123 | rollout_eval | None | False | True |
| B__v3_canonical__minus020__stoch_seed123 | b_stoch_native | 1 | B | isometric_comparable | minus020 | stochastic | 123 | rollout_eval | None | False | True |
| B__v3_canonical__minus020__stoch_seed124 | b_stoch_native | 1 | B | isometric_comparable | minus020 | stochastic | 124 | rollout_eval | None | False | True |
| B__v3_canonical__minus020__stoch_seed125 | b_stoch_native | 1 | B | isometric_comparable | minus020 | stochastic | 125 | rollout_eval | None | False | True |
| B__v3_canonical__nominal__stoch_seed123 | b_stoch_native | 1 | B | isometric_comparable | nominal | stochastic | 123 | rollout_eval | None | False | True |
| B__v3_canonical__nominal__stoch_seed124 | b_stoch_native | 1 | B | isometric_comparable | nominal | stochastic | 124 | rollout_eval | None | False | True |
| B__v3_canonical__nominal__stoch_seed125 | b_stoch_native | 1 | B | isometric_comparable | nominal | stochastic | 125 | rollout_eval | None | False | True |
| B__v3_canonical__plus020__stoch_seed123 | b_stoch_native | 1 | B | isometric_comparable | plus020 | stochastic | 123 | rollout_eval | None | False | True |
| B__v3_canonical__plus020__stoch_seed124 | b_stoch_native | 1 | B | isometric_comparable | plus020 | stochastic | 124 | rollout_eval | None | False | True |
| B__v3_canonical__plus020__stoch_seed125 | b_stoch_native | 1 | B | isometric_comparable | plus020 | stochastic | 125 | rollout_eval | None | False | True |
| B__v3_canonical__nominal__stoch_seed123_rep2 | b_stoch_native | 1 | B | isometric_comparable | nominal | stochastic | 123 | rollout_eval | None | False | True |
| C__v3_canonical__minus020__det | c_det | 1 | C | isometric_comparable | minus020 | deterministic | 123 | rollout_eval | None | True | True |
| C__v3_canonical__nominal__det | c_det | 1 | C | isometric_comparable | nominal | deterministic | 123 | rollout_eval | None | True | True |
| C__v3_canonical__plus020__det | c_det | 1 | C | isometric_comparable | plus020 | deterministic | 123 | rollout_eval | None | True | True |
| C__v3_canonical__minus020__stoch_seed123 | c_stoch_s005 | 1 | C | isometric_comparable | minus020 | stochastic | 123 | rollout_eval | None | True | True |
| C__v3_canonical__minus020__stoch_seed124 | c_stoch_s005 | 1 | C | isometric_comparable | minus020 | stochastic | 124 | rollout_eval | None | True | True |
| C__v3_canonical__minus020__stoch_seed125 | c_stoch_s005 | 1 | C | isometric_comparable | minus020 | stochastic | 125 | rollout_eval | None | True | True |
| C__v3_canonical__nominal__stoch_seed123 | c_stoch_s005 | 1 | C | isometric_comparable | nominal | stochastic | 123 | rollout_eval | None | True | True |
| C__v3_canonical__nominal__stoch_seed124 | c_stoch_s005 | 1 | C | isometric_comparable | nominal | stochastic | 124 | rollout_eval | None | True | True |
| C__v3_canonical__nominal__stoch_seed125 | c_stoch_s005 | 1 | C | isometric_comparable | nominal | stochastic | 125 | rollout_eval | None | True | True |
| C__v3_canonical__plus020__stoch_seed123 | c_stoch_s005 | 1 | C | isometric_comparable | plus020 | stochastic | 123 | rollout_eval | None | True | True |
| C__v3_canonical__plus020__stoch_seed124 | c_stoch_s005 | 1 | C | isometric_comparable | plus020 | stochastic | 124 | rollout_eval | None | True | True |
| C__v3_canonical__plus020__stoch_seed125 | c_stoch_s005 | 1 | C | isometric_comparable | plus020 | stochastic | 125 | rollout_eval | None | True | True |
| PASSTHROUGH_B__v3_canonical__nominal__det | passthrough | 1 | PASSTHROUGH_B | integrity_control | nominal | deterministic | 123 | f1_rollout_aiso | passthrough | False | True |
| A_ISO39CLK_V3__v3_canonical__minus020__det | aiso_clk_diag | 1 | A_ISO39CLK_V3 | diagnostic_privileged_clock | minus020 | deterministic | 123 | f1_rollout_aiso | aiso6clk | False | False |
| A_ISO39CLK_V3__v3_canonical__nominal__det | aiso_clk_diag | 1 | A_ISO39CLK_V3 | diagnostic_privileged_clock | nominal | deterministic | 123 | f1_rollout_aiso | aiso6clk | False | False |
| A_ISO39CLK_V3__v3_canonical__plus020__det | aiso_clk_diag | 1 | A_ISO39CLK_V3 | diagnostic_privileged_clock | plus020 | deterministic | 123 | f1_rollout_aiso | aiso6clk | False | False |
| D__v3_canonical__minus020__det | d_det | 3 | D | isometric_comparable | minus020 | deterministic | 123 | rollout_eval | None | True | True |
| D__v3_canonical__nominal__det | d_det | 3 | D | isometric_comparable | nominal | deterministic | 123 | rollout_eval | None | True | True |
| D__v3_canonical__plus020__det | d_det | 3 | D | isometric_comparable | plus020 | deterministic | 123 | rollout_eval | None | True | True |
| D__v3_canonical__minus020__stoch_seed123 | d_stoch_s005 | 3 | D | isometric_comparable | minus020 | stochastic | 123 | rollout_eval | None | True | True |
| D__v3_canonical__minus020__stoch_seed124 | d_stoch_s005 | 3 | D | isometric_comparable | minus020 | stochastic | 124 | rollout_eval | None | True | True |
| D__v3_canonical__minus020__stoch_seed125 | d_stoch_s005 | 3 | D | isometric_comparable | minus020 | stochastic | 125 | rollout_eval | None | True | True |
| D__v3_canonical__nominal__stoch_seed123 | d_stoch_s005 | 3 | D | isometric_comparable | nominal | stochastic | 123 | rollout_eval | None | True | True |
| D__v3_canonical__nominal__stoch_seed124 | d_stoch_s005 | 3 | D | isometric_comparable | nominal | stochastic | 124 | rollout_eval | None | True | True |
| D__v3_canonical__nominal__stoch_seed125 | d_stoch_s005 | 3 | D | isometric_comparable | nominal | stochastic | 125 | rollout_eval | None | True | True |
| D__v3_canonical__plus020__stoch_seed123 | d_stoch_s005 | 3 | D | isometric_comparable | plus020 | stochastic | 123 | rollout_eval | None | True | True |
| D__v3_canonical__plus020__stoch_seed124 | d_stoch_s005 | 3 | D | isometric_comparable | plus020 | stochastic | 124 | rollout_eval | None | True | True |
| D__v3_canonical__plus020__stoch_seed125 | d_stoch_s005 | 3 | D | isometric_comparable | plus020 | stochastic | 125 | rollout_eval | None | True | True |

## Stage commands (exact)

### stage_1_adapter_crosscheck

```
/opt/anaconda3/envs/envCMC-rllib/bin/python "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/baseline_MLP/validation/f1_ablation_2026-08-23/f1_adapter_crosscheck.py"
```

### stage_1_derive_modules

```
/opt/anaconda3/envs/envCMC-rllib/bin/python "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/baseline_MLP/validation/f1_ablation_2026-08-23/f1_sigma_variant.py" --source-module "/Users/tommy/Documents/CMC-like-Simulator - Claude/validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/rl_module_last" --output-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/derived_modules/B_sigma0005" --sigma 0.005 --materialize
```
```
/opt/anaconda3/envs/envCMC-rllib/bin/python "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/baseline_MLP/validation/f1_ablation_2026-08-23/f1_sigma_variant.py" --source-module "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/training/MLP_imitation_native_v26_08-20-2026_june_equiv_100iter/rl_module_best" --output-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/derived_modules/V26_39D_sigma0005" --sigma 0.005 --materialize
```

### stage_1_rollouts

```
/opt/anaconda3/envs/envCMC-rllib/bin/python "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/baseline_MLP/validation/f1_ablation_2026-08-23/f1_matrix.py" --execute --stage 1 --workers 5
```

### stage_2_dataset

```
/opt/anaconda3/envs/envCMC-rllib/bin/python "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/baseline_MLP/validation/f1_ablation_2026-08-23/f1_dataset.py" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__minus020__stoch_seed123" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__minus020__stoch_seed124" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__minus020__stoch_seed125" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__nominal__stoch_seed123" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__nominal__stoch_seed124" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__nominal__stoch_seed125" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__plus020__stoch_seed123" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__plus020__stoch_seed124" --b-job-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/b_stoch_native/B__v3_canonical__plus020__stoch_seed125" --aiso-adapter-trace "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/aiso_det/A_ISO39_V3__v3_canonical__minus020__det/f1_adapter_trace.json" --aiso-adapter-trace "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/aiso_det/A_ISO39_V3__v3_canonical__nominal__det/f1_adapter_trace.json" --aiso-adapter-trace "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/rollouts/aiso_det/A_ISO39_V3__v3_canonical__plus020__det/f1_adapter_trace.json" --teacher-module "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/training/MLP_imitation_native_v26_08-20-2026_june_equiv_100iter/rl_module_best" --out-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/datasets" --stamp D_v1
```

### stage_2_refit

```
/opt/anaconda3/envs/envCMC-rllib/bin/python "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/baseline_MLP/validation/f1_ablation_2026-08-23/f1_refit.py" --source-module "/Users/tommy/Documents/CMC-like-Simulator - Claude/validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/rl_module_last" --dataset-npz "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/datasets/f1_dataset_D_v1.npz" --dataset-receipt "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/datasets/f1_dataset_D_v1.json" --out-dir "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1/refit/D_refit_v1" --fit
```

### stage_3_rollouts

```
/opt/anaconda3/envs/envCMC-rllib/bin/python "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/baseline_MLP/validation/f1_ablation_2026-08-23/f1_matrix.py" --execute --stage 3 --workers 5
```

### stage_4_analysis

```
/opt/anaconda3/envs/envCMC-rllib/bin/python "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/baseline_MLP/validation/f1_ablation_2026-08-23/f1_analysis.py" --manifest-root "/Users/tommy/Documents/CMC-like-Simulator - Claude/Trajectory Generator/runs/rollout/validation/f1_ablation_runs/2026-08-23_F1_ablation_39to35_sigma_r1"
```
