# SUPERSEDED — revisione r1 (2026-08-22)

Questa directory e' la prima passata della Fase 0 ed e' **superata**; i suoi artefatti restano intatti solo come traccia storica e NON sono candidati al Gate F0.

Difetti noti di r1:

- il modulo "embedded" dei full checkpoint era letto dal `module_state.pkl` vuoto (5 byte) del MultiRLModule invece di `learner_group/learner/rl_module/default_policy/module_state.pkl`: cross-check actor/critic FAIL spurii;
- i contatori di terminazione RLlib (lifetime) venivano sommati fra iterazioni (valori gonfiati);
- nessuna verifica fail-closed delle receipt, path `/opt/anaconda3` hard-coded nel driver.

Revisione valida: vedere `REVISIONS.md` nella directory padre (candidata: r3).
