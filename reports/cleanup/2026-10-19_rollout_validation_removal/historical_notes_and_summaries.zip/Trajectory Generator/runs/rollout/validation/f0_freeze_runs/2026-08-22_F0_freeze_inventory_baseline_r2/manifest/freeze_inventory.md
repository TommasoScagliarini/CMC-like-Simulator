# F0 — Freeze inventory (digest e manifest) — revisione r2

Generato: 2026-08-22T16:56:28+00:00 — git HEAD `04c0c470da81` (main), worktree sporco: 6 voci (preservate).

Convenzioni digest: `actor (ws)` = `warm_start.actor_state_digest`; `actor (pi)` = `compare_policy_checkpoints._actor_digest`; critic = aggregato su `vf*` del modulo learner nel full checkpoint (gli export `rl_module_*` sono actor-only).

## Moduli actor esportati (rl_module)

| modulo | path | width | actor (ws) | actor (pi) | critic | log-std rows zero | log-std bias | sigma (se costante) | entropia nat (se costante) |
|---|---|---|---|---|---|---|---|---|---|
| JUN23_IMIT_BEST | Trajectory Generator/runs/training/MLP_imitation_training_06-23-2026_grfsoft_knee1_ankle2_100iter/rl_module_best | 31 | 686e197dc71d5f6e | 5be9e663ac056697 | N/A (export actor-only) | False | [-0.0573, -0.0491] | [0.94427, 0.95212] | 2.7315 |
| JUL_PORT_INITIAL_WARM_START | Trajectory Generator/runs/training/validation/controller_memory_ablation/2026-07-13_markov35_zero_iter_port/rl_module_initial_warm_start | 35 | 42837d4802d71b70 | d62c74b289f635b6 | N/A (export actor-only) | True | [-5.2983, -5.2983] | [0.005, 0.005] | -7.7588 |
| JUL_ADAPTED_TARGET_DOMAIN | Trajectory Generator/runs/training/target_domain_markov35_phase_aligned_scaled_full_r32_alt8_2026-07-13/rl_module_target_adapted | 35 | a0801a9e635db4f2 | 585e33257a0b5fe5 | N/A (export actor-only) | True | [-5.2983, -5.2983] | [0.005, 0.005] | -7.7588 |
| JUL_WARMUP_INITIAL_WARM_START | validation/critic_warmup/2026-07-13_markov35_phase_aligned_sigma0005_iter1_retry/rl_module_initial_warm_start | 35 | a0801a9e635db4f2 | 585e33257a0b5fe5 | N/A (export actor-only) | True | [-5.2983, -5.2983] | [0.005, 0.005] | -7.7588 |
| JUL_WARMUP_BEST | validation/critic_warmup/2026-07-13_markov35_phase_aligned_sigma0005_iter1_retry/rl_module_best | 35 | a0801a9e635db4f2 | 585e33257a0b5fe5 | N/A (export actor-only) | True | [-5.2983, -5.2983] | [0.005, 0.005] | -7.7588 |
| V26_IMIT_LAST | Trajectory Generator/runs/training/MLP_imitation_native_v26_08-20-2026_june_equiv_100iter/rl_module_last | 39 | f1385ca1d9595325 | 8691723937e244fd | N/A (export actor-only) | False | [-0.0343, -0.0344] | [0.96631, 0.96622] | 2.7692 |
| B0820_WARMUP_INITIAL_WARM_START | validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/rl_module_initial_warm_start | 35 | ce46f729080b0692 | aea061425126c09f | N/A (export actor-only) | False | [-0.0383, -0.0329] | [0.96238, 0.9676] | 2.7666 |
| B0820_WARMUP_BEST | validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/rl_module_best | 35 | ce46f729080b0692 | aea061425126c09f | N/A (export actor-only) | False | [-0.0383, -0.0329] | [0.96238, 0.9676] | 2.7666 |
| JUL_H0 | validation/critic_warmup/2026-07-13_markov35_phase_aligned_sigma0005_iter1_retry/rl_module_last | 35 | a0801a9e635db4f2 | 585e33257a0b5fe5 | N/A (export actor-only) | True | [-5.2983, -5.2983] | [0.005, 0.005] | -7.7588 |
| JUL_BEST | Trajectory Generator/runs/training/validation/warm_start_h1_runs/2026-07-15_h0_exact_interleaved_lr5e-7_iter2-51_pilot50/rl_module_best | 35 | 08ce5abe7f82f82b | 03f20fa8862837df | N/A (export actor-only) | True | [-5.2983, -5.2983] | [0.005, 0.005] | -7.7588 |
| JUL_LAST | Trajectory Generator/runs/training/validation/warm_start_h1_runs/2026-07-15_h0_exact_interleaved_lr5e-7_iter2-51_pilot50/rl_module_last | 35 | 984027885d53daea | 97e49b717dcf0b8a | N/A (export actor-only) | True | [-5.2983, -5.2983] | [0.005, 0.005] | -7.7588 |
| V26_39D | Trajectory Generator/runs/training/MLP_imitation_native_v26_08-20-2026_june_equiv_100iter/rl_module_best | 39 | 5bbc6cbd3c7e3ec3 | 29a5cd0791d26082 | N/A (export actor-only) | False | [-0.0383, -0.0329] | [0.96238, 0.9676] | 2.7666 |
| B0820_H0 | validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/rl_module_last | 35 | ce46f729080b0692 | aea061425126c09f | N/A (export actor-only) | False | [-0.0383, -0.0329] | [0.96238, 0.9676] | 2.7666 |
| B0820_V2_BEST | Trajectory Generator/runs/training/MLP_ExNovo_B0820_from_zero_50iter/rl_module_best | 35 | 6a1efcce10684766 | c8e5c1df7ff7fab4 | N/A (export actor-only) | False | [-0.0383, -0.0329] | [0.96238, 0.9676] | 2.7666 |
| B0820_V2_LAST | Trajectory Generator/runs/training/MLP_ExNovo_B0820_from_zero_50iter/rl_module_last | 35 | 8a5200c4e29939d1 | 41a0d88f89da6e2e | N/A (export actor-only) | False | [-0.0383, -0.0329] | [0.96238, 0.9676] | 2.7666 |
| B0820_V3_BEST | Trajectory Generator/runs/training/MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter/rl_module_best | 35 | 339f2e203af077f5 | caf23dbb909bd79f | N/A (export actor-only) | False | [-0.0383, -0.0329] | [0.96238, 0.9676] | 2.7666 |
| B0820_V3_LAST | Trajectory Generator/runs/training/MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter/rl_module_last | 35 | d7a9158eb32cc587 | af19c86e128d0bab | N/A (export actor-only) | False | [-0.0383, -0.0329] | [0.96238, 0.9676] | 2.7666 |

## Full checkpoint (Algorithm: learner module actor+critic, optimizer)

| checkpoint | path | file | bytes | tree digest | logical iter | actor (ws) learner | critic digest | weights_seq_no | optimizer lr | Adam step min/max |
|---|---|---|---|---|---|---|---|---|---|---|
| JUL_WARMUP_checkpoint_last | validation/critic_warmup/2026-07-13_markov35_phase_aligned_sigma0005_iter1_retry/checkpoint_last | 24 | 1898007 | 6b1bd9869a44a93a | 1 | a0801a9e635db4f2 | 4584399f63781c48 | 1 | [0.0001] | [81.0, 81.0] |
| JUL_PILOT_checkpoint_best | Trajectory Generator/runs/training/validation/warm_start_h1_runs/2026-07-15_h0_exact_interleaved_lr5e-7_iter2-51_pilot50/checkpoint_best | 24 | 2509455 | a27b08292479e024 | 24 | 08ce5abe7f82f82b | ac116616e3eececc | 24 | [5e-07] | [207.0, 207.0] |
| JUL_PILOT_checkpoint_last | Trajectory Generator/runs/training/validation/warm_start_h1_runs/2026-07-15_h0_exact_interleaved_lr5e-7_iter2-51_pilot50/checkpoint_last | 24 | 2509815 | d4be6f1ba5ed6e12 | 51 | 984027885d53daea | 0b603997c6278990 | 51 | [5e-07] | [450.0, 450.0] |
| V26_IMIT_checkpoint_best | Trajectory Generator/runs/training/MLP_imitation_native_v26_08-20-2026_june_equiv_100iter/checkpoint_best | 24 | 2559053 | 2e9b946fb7b309f8 | 87 | 5bbc6cbd3c7e3ec3 | 18e003e6e6250f8a | 87 | [0.0001] | [7666.0, 7666.0] |
| B0820_WARMUP_checkpoint_last | validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/checkpoint_last | 24 | 1931182 | a1ca8b7916b08fe8 | 5 | ce46f729080b0692 | dc3c70d2442c112f | 5 | [5e-07] | [45.0, 45.0] |
| B0820_V2_checkpoint_best | Trajectory Generator/runs/training/MLP_ExNovo_B0820_from_zero_50iter/checkpoint_best | 24 | 2539889 | 8fc05cf7062cdf16 | 33 | 6a1efcce10684766 | 1e62ee1c4283d1f1 | 33 | [5e-07] | [252.0, 252.0] |
| B0820_V2_checkpoint_last | Trajectory Generator/runs/training/MLP_ExNovo_B0820_from_zero_50iter/checkpoint_last | 24 | 2539919 | 73a8666bcaaa3ecb | 55 | 8a5200c4e29939d1 | 9a86b75878ed4b02 | 55 | [5e-07] | [450.0, 450.0] |
| B0820_V3_checkpoint_best | Trajectory Generator/runs/training/MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter/checkpoint_best | 24 | 2540019 | 6ccbfde0b2d542d1 | 39 | 339f2e203af077f5 | b02369c2237ebb60 | 39 | [5e-07] | [306.0, 306.0] |
| B0820_V3_checkpoint_last | Trajectory Generator/runs/training/MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter/checkpoint_last | 24 | 2539749 | 3f1896035e248bbe | 55 | d7a9158eb32cc587 | 9778f4dd464a0c53 | 55 | [5e-07] | [450.0, 450.0] |

## Config e profili

| artefatto | path | sha256 | git blob | tracked |
|---|---|---|---|---|
| canonical_training_exnovo_cfg (editable, worktree) | Trajectory Generator/baseline_MLP/training_exnovo_cfg.yaml | 092363e6bf5a411f | 458abca02ba5 | True |
| chain_snapshot_exnovo_v26_B0820_chain | Trajectory Generator/baseline_MLP/experimental_configs/exnovo_v26_B0820_chain.yaml | b3e951ab43c9dec5 | 874795204eb7 | True |
| july_imitation_training_cfg | Trajectory Generator/baseline_MLP/training_cfg.yaml | a0a8d16df1d34bc4 | fbabac656979 | True |
| JUN23_resolved | Trajectory Generator/runs/training/MLP_imitation_training_06-23-2026_grfsoft_knee1_ankle2_100iter/training_cfg.resolved.yaml | fbe1fd3f03bdd118 |  | False |
| JUL_WARMUP_resolved | validation/critic_warmup/2026-07-13_markov35_phase_aligned_sigma0005_iter1_retry/training_cfg.resolved.yaml | 6904f7a9000b63b5 | bb7c0c86e99d | True |
| JUL_PILOT_resolved | Trajectory Generator/runs/training/validation/warm_start_h1_runs/2026-07-15_h0_exact_interleaved_lr5e-7_iter2-51_pilot50/training_cfg.resolved.yaml | f89d6b5ee9337c61 |  | False |
| V26_IMIT_resolved | Trajectory Generator/runs/training/MLP_imitation_native_v26_08-20-2026_june_equiv_100iter/training_cfg.resolved.yaml | aaf84cfd5be75672 |  | False |
| B0820_WARMUP_resolved | validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/training_cfg.resolved.yaml | 9882b33d385ada05 | 8c915a37cbbc | True |
| B0820_V2_resolved | Trajectory Generator/runs/training/MLP_ExNovo_B0820_from_zero_50iter/training_cfg.resolved.yaml | 0a19375462ff296f |  | False |
| B0820_V3_resolved | Trajectory Generator/runs/training/MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter/training_cfg.resolved.yaml | a870cc38a77d853b |  | False |
| grf_profile_tangent_v2 (B0820/giugno) | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_online_full_wrench_residual_tangent_v2.json | 09e04ab94954703d | 9b660d241d63 | True |
| grf_profile_grf_correct_magnitude (luglio) | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_correct_magnitude.json | 09e04ab94954703d | 9b660d241d63 | True |
| grf_detector_profile_HS-TO | online_grf_profiles/AB06_SEASEA_stiff321_500_pi_grf_detector_HS-TO.json | 61ea948a3c0613e5 | a0fcfe7fb3ee | True |
| binary_phase_detector_v25_selected_candidate_profile | validation/binary_phase_detector_v25_geometry_runs/2026-08-04_local_reach_sweep_dev02_04_08/selected_candidate_profile.json | db704e502b99e49b | e92ed76398e6 | True |
| morphology_profile_event_warped (B0820) | Trajectory Generator/baseline_MLP/morphology_profiles/ab06_prosthetic_event_warped_mean_std_corridor.json | 33b1dd7cb0db4011 | b6eafd07acac | True |
| morphology_profile_legacy_mean_std (luglio, peso 0) | Trajectory Generator/baseline_MLP/morphology_profiles/ab06_prosthetic_mean_std_corridor.json | 6307119c2bb23383 | 877406707fc2 | True |
| setup_xml_AB06_SEASEA | models/AB06_SEASEA_Threadmill/AB06_SEASEA_stiff321_500_pi_setup.xml | 5fa4748e537ae1a0 | 0eb622069659 | True |

## Cross-check dei digest dichiarati

| check | atteso | calcolato | sorgente | esito / motivo |
|---|---|---|---|---|
| B0820 transplant source_actor_digest == V26_39D actor digest | 5bbc6cbd3c7e3ec3 | 5bbc6cbd3c7e3ec3 | actor_transplant_report.json (B0820) | PASS |
| B0820 transplant target_actor_digest_after == B0820_WARMUP_INITIAL_WARM_START | ce46f729080b0692 | ce46f729080b0692 | actor_transplant_report.json (B0820) | PASS |
| B0820 warmup freeze audit (after iter 5) == B0820_H0 exported actor digest | ce46f729080b0692 | ce46f729080b0692 | summary.json actor_freeze_audit (B0820 warmup) | PASS |
| B0820 warmup critic audit (after iter 5) == critic digest embedded in B0820_WARMUP checkpoint_last (learner module) | dc3c70d2442c112f | dc3c70d2442c112f | summary.json critic_state_audit vs learner_group/learner/rl_module/default_policy | PASS |
| B0820 transplant learner_non_actor digest (fresh critic before warmup) == critic audit before_training | 5ce4ef41d5677623 | 5ce4ef41d5677623 | actor_transplant_report.json vs summary.json (B0820) | PASS |
| July transplant source == JUL_ADAPTED_TARGET_DOMAIN actor digest | a0801a9e635db4f2 | a0801a9e635db4f2 | actor_transplant_report.json (luglio) | PASS |
| July warmup freeze audit (after iter 1) == JUL_H0 exported actor digest | a0801a9e635db4f2 | a0801a9e635db4f2 | summary.json actor_freeze_audit (luglio) | PASS |
| July warmup critic audit (after iter 1) == critic digest embedded in JUL_WARMUP checkpoint_last (learner module) | 4584399f63781c48 | 4584399f63781c48 | summary.json critic_state_audit vs learner module (luglio) | PASS |
| July adaptation source_actor_digest == JUL_PORT_INITIAL_WARM_START | 42837d4802d71b70 | 42837d4802d71b70 | adaptation_report.json (markov35 r32) | PASS |
| July adaptation adapted_actor_digest == JUL_ADAPTED_TARGET_DOMAIN | a0801a9e635db4f2 | a0801a9e635db4f2 | adaptation_report.json (markov35 r32) | PASS |
| July pilot drift audit reference_h0_actor_digest (pi-canonical convention) == JUL_H0 pi digest | 585e33257a0b5fe5 | 585e33257a0b5fe5 | policy_drift_from_h0_milestones.json | PASS |
| V26_39D adjacent manifest actor_digest == computed | 5bbc6cbd3c7e3ec3 | 5bbc6cbd3c7e3ec3 | rl_module_best/actor_feature_manifest.json (V26) | PASS |
| JUL_ADAPTED adjacent manifest actor_digest == computed | a0801a9e635db4f2 | a0801a9e635db4f2 | actor_feature_manifest.json (markov35 r32) | PASS |
| GRF profile SHA tangent_v2 == grf_correct_magnitude | 09e04ab94954703d | 09e04ab94954703d | online_grf_profiles/*.json | PASS |
| B0820_WARMUP_checkpoint_last learner-module actor == exported B0820_H0 actor | ce46f729080b0692 | ce46f729080b0692 | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| JUL_WARMUP_checkpoint_last learner-module actor == exported JUL_H0 actor | a0801a9e635db4f2 | a0801a9e635db4f2 | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| V26_IMIT_checkpoint_best learner-module actor == exported V26_39D actor | 5bbc6cbd3c7e3ec3 | 5bbc6cbd3c7e3ec3 | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| B0820_V3_checkpoint_best learner-module actor == exported B0820_V3_BEST actor | 339f2e203af077f5 | 339f2e203af077f5 | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| B0820_V3_checkpoint_last learner-module actor == exported B0820_V3_LAST actor | d7a9158eb32cc587 | d7a9158eb32cc587 | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| B0820_V2_checkpoint_best learner-module actor == exported B0820_V2_BEST actor | 6a1efcce10684766 | 6a1efcce10684766 | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| B0820_V2_checkpoint_last learner-module actor == exported B0820_V2_LAST actor | 8a5200c4e29939d1 | 8a5200c4e29939d1 | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| JUL_PILOT_checkpoint_best learner-module actor == exported JUL_BEST actor | 08ce5abe7f82f82b | 08ce5abe7f82f82b | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| JUL_PILOT_checkpoint_last learner-module actor == exported JUL_LAST actor | 984027885d53daea | 984027885d53daea | full checkpoint learner_group/learner/rl_module/default_policy vs rl_module export | PASS |
| critic digest on exported module JUL_H0 | - | - | validation/critic_warmup/2026-07-13_markov35_phase_aligned_sigma0005_iter1_retry/rl_module_last | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| critic digest on exported module JUL_BEST | - | - | Trajectory Generator/runs/training/validation/warm_start_h1_runs/2026-07-15_h0_exact_interleaved_lr5e-7_iter2-51_pilot50/rl_module_best | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| critic digest on exported module JUL_LAST | - | - | Trajectory Generator/runs/training/validation/warm_start_h1_runs/2026-07-15_h0_exact_interleaved_lr5e-7_iter2-51_pilot50/rl_module_last | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| critic digest on exported module V26_39D | - | - | Trajectory Generator/runs/training/MLP_imitation_native_v26_08-20-2026_june_equiv_100iter/rl_module_best | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| critic digest on exported module B0820_H0 | - | - | validation/critic_warmup/2026-08-20_B0820_native_v26_frozen_actor_iter5/rl_module_last | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| critic digest on exported module B0820_V2_BEST | - | - | Trajectory Generator/runs/training/MLP_ExNovo_B0820_from_zero_50iter/rl_module_best | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| critic digest on exported module B0820_V2_LAST | - | - | Trajectory Generator/runs/training/MLP_ExNovo_B0820_from_zero_50iter/rl_module_last | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| critic digest on exported module B0820_V3_BEST | - | - | Trajectory Generator/runs/training/MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter/rl_module_best | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| critic digest on exported module B0820_V3_LAST | - | - | Trajectory Generator/runs/training/MLP_ExNovo_B0820_fsmv3_fixedcorridor_50iter/rl_module_last | N/A: exported rl_module_* are actor-only (state has no vf* keys); critic digest is taken from the learner module of the full checkpoint instead |
| env_runner module weights in full checkpoints | - | - | full checkpoints | N/A: env_runner/ holds only connector/runner state (state.pkl ~50 B); EnvRunner weights are synced from the learner at restore, not persisted separately |

Tutti gli artefatti risolvibili: **True** — cross-check: PASS 23, FAIL 0, N/A 10 — nessun FAIL: **True**.
