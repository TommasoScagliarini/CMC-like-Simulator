# SUPERSEDED — revisione r2 (2026-08-22)

Questa directory e' stata generata prima del secondo giro di audit architetturale ed e' **superata**; i suoi artefatti restano intatti e NON sono candidati al Gate F0.

Difetti noti di r2 (corretti in r3):

- driver: status `ok` non richiedeva `rollout_summary.ok == True` ne' la presenza della trace; nessun ricalcolo dei digest di summary/trace nella verifica delle receipt; nessun preflight sincrono dell'intera matrice prima del pool;
- classificazione impropria dei job storici come "riproduzione" (sono replay della configurazione storica sul codice HEAD corrente, non riproduzioni bit-exact);
- riferimenti storici senza SHA del summary;
- censimento: frase "prima riga == ultima riga warmup" imprecisa (corretto: first-row delta is measured against warmup last row) e chiavi dei contatori non ordinate;
- tree digest dei checkpoint con path specifici dell'host (non POSIX);
- self-test insufficiente (assert vacuo, summary vuoto accettato).

Revisione valida: vedere `REVISIONS.md` nella directory padre (candidata: r3).
